﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Queries
{
    public class queriesHanna
    {
        #region BuscarDadosHanna
        public const string BuscarDados = @"
                                            SELECT 'Recebimento' AS ""Tipo"",
		                                            PDN.""DocNum"",
                                                    PDN.""DocEntry"",
		                                            PDN.""TaxDate"",
		                                            PDN.""CardCode"",
		                                            PDN.""CardName"",
		                                            PDN.""DocTotal"",
		                                            PDN.""BPLName""
                                            FROM OPDN PDN
                                            WHERE ""U_RSD_StMagLog"" = 'I' AND ""U_RSD_PrcMagLog"" = 'N' AND
                                            ""TaxDate"" BETWEEN TO_DATE({0},'YYYYMMDD') AND TO_DATE({1}, 'YYYYMMDD')
                                            UNION ALL
                                            SELECT 'NFS' AS ""Tipo"",
	                                                INV.""DocNum"",  
                                                    INV.""DocEntry"",
	                                                INV.""TaxDate"",
	                                                INV.""CardCode"",
	                                                INV.""CardName"",
	                                                INV.""DocTotal"",
	                                                BPL.""BPLName""
                                            FROM OINV INV
                                            INNER JOIN OBPL BPL ON INV.""BPLId"" = BPL.""BPLId""
                                            WHERE ""U_RSD_StMagLog"" = 'I' AND ""U_RSD_PrcMagLog"" = 'N' AND
                                            INV.""TaxDate"" BETWEEN  TO_DATE({0},'YYYYMMDD') AND TO_DATE({1}, 'YYYYMMDD')";
        #endregion

        #region BuscarDadosHannaItem
        public const string BuscarDadosItemRecMercadoria = @"SELECT PDN1.""DocEntry"" AS ""Numero do Documento"",
	                                                                PDN1.""ItemCode"" AS ""Item"",
	                                                                PDN1.""Dscription"" AS ""Descrição"",
		                                                            PDN1.""Quantity"" AS ""Quantidade"",
	                                                                ITM.""SalUnitMsr"" AS ""Unidade de Medida"",
	                                                                 ""U_RSD_QtdConf"" AS ""Quantidade Conferida"",
	                                                                 (PDN1.""Quantity"" - ""U_RSD_QtdConf"") AS ""Divergência"" 	
                                                                    FROM PDN1 
                                                                    INNER JOIN OITM ITM ON PDN1.""ItemCode"" = ITM.""ItemCode"" 
                                                                    WHERE PDN1.""DocEntry"" = {0}";
        #endregion

        #region BuscarDadosHannaItem
        public const string BuscarDadosItemNotaFiscalSaida = @"SELECT INV1.""DocEntry"" AS ""Numero do Documento"",
	                                                   INV1.""ItemCode"" AS ""Item"",
	                                                   INV1.""Dscription"" AS ""Descrição"",
	                                                   INV1.""Quantity"" AS ""Quantidade"",
	                                                   ITM.""SalUnitMsr"" AS ""Unidade de Medida"",
	                                                   ""U_RSD_QtdConf"" AS ""Quantidade Conferida"",
	                                                   (INV1.""Quantity"" - ""U_RSD_QtdConf"") AS ""Divergência"" 		
                                                FROM INV1 
                                                INNER JOIN OITM ITM ON INV1.""ItemCode"" = ITM.""ItemCode"" 
                                                WHERE INV1.""DocEntry"" = {0}";
        #endregion

        #region BuscarDadosCETHanna
        public const string BuscarDadosCET = @"
                                                SELECT 
                                                    DRF.""DocEntry"",
	                                                DRF.""DocNum"",
	                                                DRF.""CardCode"",
	                                                DRF.""DocDate"",
	                                                DRF.""DocDueDate"",
	                                                DRF.""CardName"",
	                                                DRF.""DocTotal""
                                                FROM ODRF DRF
                                                INNER JOIN DRF12 ON DRF.""DocEntry"" = DRF12.""DocEntry""
                                                WHERE DRF.""ObjType"" = 15 AND 
                                                      (DRF12.""Carrier"" IS NULL OR DRF12.""Carrier"" = '')";
        #endregion

    }

    public class queriesMSSQL
    {
        #region BuscarDadosMSSQL
        public const string BuscarDados = @"DECLARE @DataDe as Date = '{0}'
                                            DECLARE @DataAte as Date = '{1}'
                                            SELECT 'Recebimento' as [Tipo],
		                                            DocNum,
                                                    DocEntry,
		                                            TaxDate,
		                                            CardCode,
		                                            CardName,
		                                            DocTotal,
		                                            BPLName
                                            FROM OPDN
                                            WHERE U_RSD_StMagLog = 'I' AND U_RSD_PrcMagLog = 'N' AND
                                            TaxDate BETWEEN  @DataDe AND @DataAte
                                            UNION ALL
                                            SELECT 'NFS' as [Tipo],
	                                                INV.DocNum,  
                                                    INV.DocEntry,
	                                                INV.TaxDate,
	                                                INV.CardCode,
	                                                INV.CardName,
	                                                INV.DocTotal,
	                                                BPL.BPLName
                                            FROM OINV INV
                                            INNER JOIN OBPL BPL ON INV.BPLId = BPL.BPLId
                                            WHERE U_RSD_StMagLog = 'I' AND U_RSD_PrcMagLog = 'N' AND
                                            INV.TaxDate BETWEEN  @DataDe AND @DataAte";
        #endregion

        #region BuscarDadosMSSQLItem
        public const string BuscarDadosItemNotaFiscalSaida = @"SELECT INV1.DocEntry as [Numero do Documento],
	                                                   INV1.ItemCode as [Item],
	                                                   INV1.Dscription as [Descrição],
	                                                   INV1.Quantity as [Quantidade],
	                                                   ITM.SalUnitMsr as [Unidade de Medida],
	                                                   U_RSD_QtdConf as [Quantidade Conferida],
	                                                   (INV1.Quantity - U_RSD_QtdConf) as [Divergência] 		
                                                FROM INV1 
                                                INNER JOIN OITM ITM ON INV1.ItemCode = ITM.ItemCode 
                                                WHERE INV1.DocEntry = {0}";
        #endregion

        #region BuscarDadosMSSQLItem
        public const string BuscarDadosItemRecMercadoria = @"SELECT PDN1.DocEntry as [Numero do Documento],
	                                                                PDN1.ItemCode as [Item],
	                                                                PDN1.Dscription as [Descrição],
		                                                            PDN1.Quantity as [Quantidade],
	                                                                ITM.SalUnitMsr as [Unidade de Medida],
	                                                                U_RSD_QtdConf as [Quantidade Conferida],
	                                                                (PDN1.Quantity - U_RSD_QtdConf) as [Divergência] 		
                                                                    FROM PDN1 
                                                                    INNER JOIN OITM ITM ON PDN1.ItemCode = ITM.ItemCode 
                                                                    WHERE PDN1.DocEntry = {0}";
        #endregion

        #region BuscarDadosCETMSSQL
        public const string BuscarDadosCET = @" SELECT 
                                                DRF.DocEntry,
	                                            DRF.DocNum,
	                                            DRF.CardCode,
	                                            DRF.DocDate,
	                                            DRF.DocDueDate,
	                                            DRF.CardName,
	                                            DRF.DocTotal
                                                FROM ODRF DRF
                                                INNER JOIN DRF12 ON DRF.DocEntry = DRF12.DocEntry
                                                WHERE DRF.ObjType = 15 AND
	                                            DRF12.Carrier IS NULL OR DRF12.Carrier = ''";
        #endregion

    }
}
