﻿using SAPbobsCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Service
{
    public class RecMercadoriaService
    {
        private Company oCmp { get; set; }

        public RecMercadoriaService(Company oCmp)
        {
            this.oCmp = oCmp;
        }

        public void AtualizarPrcRecebimento(string NovoValor, int DocEntry)
        {
            Documents oRecMercadoria = (Documents)oCmp.GetBusinessObject(BoObjectTypes.oPurchaseDeliveryNotes);

            oRecMercadoria.GetByKey(DocEntry);

            oRecMercadoria.UserFields.Fields.Item("U_RSD_PrcMagLog").Value = NovoValor;

            int retorno = oRecMercadoria.Update();

            if (retorno != 0) throw new Exception($"Ocorreu um erro ao atualizar o recebimento de mercadoria: {DocEntry.ToString()}.");
        }


    }
}
