﻿using AssistenteDivergencia_UI.Models;
using SAPbobsCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Service
{
    public class ADService
    {
        private Company OCmp { get; set; }
        private string Query { get; set; }
        private string QueryItemNotaFiscalSaida { get; set; }
        private string QueryItemRecMercadoria { get; set; }

        public ADService(Company oCmp)
        {
            this.OCmp = oCmp;

            if (oCmp.DbServerType == BoDataServerTypes.dst_HANADB)
                Query = Queries.queriesHanna.BuscarDados;
            else
                Query = Queries.queriesMSSQL.BuscarDados;

            if (oCmp.DbServerType == BoDataServerTypes.dst_HANADB)
                QueryItemNotaFiscalSaida = Queries.queriesHanna.BuscarDadosItemNotaFiscalSaida;
            else
                QueryItemNotaFiscalSaida = Queries.queriesMSSQL.BuscarDadosItemNotaFiscalSaida;

            if (oCmp.DbServerType == BoDataServerTypes.dst_HANADB)
                QueryItemRecMercadoria = Queries.queriesHanna.BuscarDadosItemRecMercadoria;
            else
                QueryItemRecMercadoria = Queries.queriesMSSQL.BuscarDadosItemRecMercadoria;
        }
    
        
       


        public List<ADModel> BuscarListaDados(DateTime DataDe, DateTime DataAte)
        {
            List<ADModel> listaDados = new List<ADModel>();

            Recordset objRecordSet = (Recordset)OCmp.GetBusinessObject(BoObjectTypes.BoRecordset);

            objRecordSet.DoQuery(String.Format(Query, DataDe.ToString("yyyyMMdd"), DataAte.ToString("yyyyMMdd")));

            objRecordSet.MoveFirst();

            while (!objRecordSet.EoF)
            {
                ADModel dados = new ADModel();

                /*O parametro Item, recebe um objeto, caso você use um inteiro (0~N), esse inteiro indica qual é a posição
                 * da coluna no resultado da query. Caso você use uma string, a string deve ser o nome da coluna na query
                 */
                dados.NumeroPrimario = (int)objRecordSet.Fields.Item("DocEntry").Value;
                dados.Tipo = objRecordSet.Fields.Item("Tipo").Value.ToString();
                dados.Numero = (int)objRecordSet.Fields.Item("DocNum").Value;
                dados.Data = (DateTime)objRecordSet.Fields.Item("TaxDate").Value;
                dados.Nome = objRecordSet.Fields.Item("CardName").Value.ToString();
                dados.Parceiro = objRecordSet.Fields.Item("CardCode").Value.ToString();
                dados.ValorTotal = (double)objRecordSet.Fields.Item("DocTotal").Value;
                dados.Filial = objRecordSet.Fields.Item("BPLName").Value.ToString();
                

                listaDados.Add(dados);
                objRecordSet.MoveNext();
            }

            return listaDados;
        }

        public List<ADModeltem> BuscarListaDadosItem(string DocEntry, string tipo)
        {
            List<ADModeltem> listaDadosItem = new List<ADModeltem>();

            Recordset objRecordSet = (Recordset)OCmp.GetBusinessObject(BoObjectTypes.BoRecordset);

            if(tipo.ToUpper().Contains("NFS"))
                objRecordSet.DoQuery(String.Format(QueryItemNotaFiscalSaida, DocEntry));
            else
                objRecordSet.DoQuery(String.Format(QueryItemRecMercadoria, DocEntry));

            objRecordSet.MoveFirst();

            while (!objRecordSet.EoF)
            {
                ADModeltem dados = new ADModeltem();

                /*O parametro Item, recebe um objeto, caso você use um inteiro (0~N), esse inteiro indica qual é a posição
                 * da coluna no resultado da query. Caso você use uma string, a string deve ser o nome da coluna na query
                 */
              
                dados.Item = objRecordSet.Fields.Item("Item").Value.ToString();
                dados.Descricao = objRecordSet.Fields.Item("Descrição").Value.ToString();
                dados.Quantidade = objRecordSet.Fields.Item("Quantidade").Value.ToString();
                dados.UnidMedida = objRecordSet.Fields.Item("Unidade de Medida").Value.ToString();
                dados.QuantidadeConferida = objRecordSet.Fields.Item("Quantidade Conferida").Value.ToString();
                dados.Divergencia = objRecordSet.Fields.Item("Divergência").Value.ToString();


                listaDadosItem.Add(dados);
                objRecordSet.MoveNext();
            }

            return listaDadosItem;
        }
    }
}

