﻿using SAPbobsCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Service
{
    public class NotaSaidaService
    {
        private Company oCmp { get; set; }

        public NotaSaidaService(Company oCmp)
        {
            this.oCmp = oCmp;
        }

        public void AtualizarPrc(string NovoValor, int DocEntry)
        {
            Documents oNotaSaida = (Documents)oCmp.GetBusinessObject(BoObjectTypes.oInvoices);

            oNotaSaida.GetByKey(DocEntry);

            oNotaSaida.UserFields.Fields.Item("U_RSD_PrcMagLog").Value = NovoValor;

            int retorno = oNotaSaida.Update();

            if (retorno != 0) throw new Exception($"Ocorreu um erro ao atualizar a nota de saída: {DocEntry.ToString()}.");
        }

    }
}
