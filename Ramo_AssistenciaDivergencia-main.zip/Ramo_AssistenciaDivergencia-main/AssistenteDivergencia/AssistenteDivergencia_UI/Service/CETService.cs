﻿using AssistenteDivergencia_UI.Models;
using SAPbobsCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Service
{
    public class CETService
    {
        private Company OCmp { get; set; }
        private string Query { get; set; }

        public CETService(Company oCmp)
        {
            this.OCmp = oCmp;

            if (oCmp.DbServerType == BoDataServerTypes.dst_HANADB)
                Query = Queries.queriesHanna.BuscarDadosCET;
            else
                Query = Queries.queriesMSSQL.BuscarDadosCET; 
        }

        public List<CETModel> BuscarListaDados()
        {
            List<CETModel> listaDados = new List<CETModel>();

            Recordset objRecordSet = (Recordset)OCmp.GetBusinessObject(BoObjectTypes.BoRecordset);

            objRecordSet.DoQuery(Query);

            objRecordSet.MoveFirst();

            while (!objRecordSet.EoF)
            {
                CETModel dados = new CETModel();

                /*O parametro Item, recebe um objeto, caso você use um inteiro (0~N), esse inteiro indica qual é a posição
                 * da coluna no resultado da query. Caso você use uma string, a string deve ser o nome da coluna na query
                 */
                dados.NumeroInternoSAP = (int)objRecordSet.Fields.Item("DocEntry").Value;
                dados.NumeroDocumento = (int)objRecordSet.Fields.Item("DocNum").Value;
                dados.Cliente = objRecordSet.Fields.Item("CardCode").Value.ToString();
                dados.NomeCliente = objRecordSet.Fields.Item("CardName").Value.ToString();
                dados.DataLancamento = (DateTime)objRecordSet.Fields.Item("DocDate").Value;
                dados.DataEntrega = (DateTime)objRecordSet.Fields.Item("DocDueDate").Value;
                dados.Total = (double)objRecordSet.Fields.Item("DocTotal").Value;
               // dados.Transportadora = objRecordSet.Fields.Item("").Value.ToString();

                listaDados.Add(dados);
                objRecordSet.MoveNext();
            }

            return listaDados;
        }

    }
}
