﻿using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM.Framework;
using AssistenteDivergencia_UI.Tela;
using AssistenteDivergencia_UI.Configs;
using System.IO;

namespace AssistenteDivergencia_UI
{
    class Menu
    {
        public void AddMenuItems()
        {
            SAPbouiCOM.Menus oMenus = null;
            SAPbouiCOM.MenuItem oMenuItem = null;

            oMenus = Application.SBO_Application.Menus;

            SAPbouiCOM.MenuCreationParams oCreationPackage = null;
            oCreationPackage = ((SAPbouiCOM.MenuCreationParams)(Application.SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_MenuCreationParams)));
            oMenuItem = Application.SBO_Application.Menus.Item("43520"); // moudles'

            oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_POPUP;
            oCreationPackage.UniqueID = UD.MENU_PASTA_ASSISTENCIA_DIVERGENCIA;
            oCreationPackage.String = "Assistente de Integração";
            oCreationPackage.Image = Path.Combine(Directory.GetCurrentDirectory(), "Assets", "Images", "SAP_RCA.JPG");
            oCreationPackage.Enabled = true;
            oCreationPackage.Position = -1;

            oMenus = oMenuItem.SubMenus;

            try
            {
                //  If the manu already exists this code will fail
                oMenus.AddEx(oCreationPackage);
            }
            catch (Exception)
            {
                RemoveMenu();
                oMenus.AddEx(oCreationPackage);
            }

            try
            {
                oMenuItem = Application.SBO_Application.Menus.Item(UD.MENU_PASTA_ASSISTENCIA_DIVERGENCIA);
                oMenus = oMenuItem.SubMenus;


                oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
                oCreationPackage.UniqueID = UD.MENU_FORM_ASSISTENTE_INTEGRACAO;
                oCreationPackage.String = "Controle de Divergências";
                oMenus.AddEx(oCreationPackage);

                oCreationPackage.Type = SAPbouiCOM.BoMenuType.mt_STRING;
                oCreationPackage.UniqueID = UD.MENU_FORM_CONSULTA_ESBOCO_TRANSPORTADORA;
                oCreationPackage.String = "Consulta Esboço Transportadora";
                oMenus.AddEx(oCreationPackage);
            }
            catch (Exception)
            { 
                Application.SBO_Application.SetStatusBarMessage("Menu já criado.", SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
        }

        public void SBO_Application_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;

            try
            {
                if (pVal.BeforeAction && pVal.MenuUID == UD.MENU_FORM_ASSISTENTE_INTEGRACAO)
                {
                    AD activeForm = new AD();
                    activeForm.Show();
                }
                if(pVal.BeforeAction && pVal.MenuUID == UD.MENU_FORM_CONSULTA_ESBOCO_TRANSPORTADORA)
                {
                    Consulta_Esboco_Transportadora activeForm = new Consulta_Esboco_Transportadora();
                    activeForm.Show();
                }
            }
            catch (Exception ex)
            {
                Application.SBO_Application.MessageBox(ex.ToString(), 1, "Ok", "", "");
            }
        }

        public void RemoveMenu()
        {
            Application.SBO_Application.Menus.RemoveEx(UD.MENU_PASTA_ASSISTENCIA_DIVERGENCIA);
            
        }

    }
}
