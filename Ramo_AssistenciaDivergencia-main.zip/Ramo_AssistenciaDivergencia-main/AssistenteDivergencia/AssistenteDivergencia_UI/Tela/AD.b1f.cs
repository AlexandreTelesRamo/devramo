﻿using System;
using System.Collections.Generic;
using System.Xml;
using SAPbouiCOM.Framework;
using AssistenteDivergencia_UI.Models;
using System.Globalization;
using AssistenteDivergencia_UI.Service;
using SAPbobsCOM;
using System.Linq;

namespace AssistenteDivergencia_UI.Tela
{
    [FormAttribute("AssistenteDivergencia_UI.Form1", "Tela/AD.b1f")]
    class AD : UserFormBase
    {
        private SAPbouiCOM.ComboBox ComboFilial;
        private SAPbouiCOM.EditText Edt_Dde;
        private SAPbouiCOM.EditText Edt_Dat;
        private SAPbouiCOM.Button Btn_Pesquisar;

        private SAPbouiCOM.DataTable DT_Doc;
        private SAPbouiCOM.DataTable DT_Itm;
        private SAPbouiCOM.Grid Grid_Doc;
        private SAPbouiCOM.Grid Grid_Itm;

        public AD()
        {

        }
        /// <summary>
        /// Initialize components. Called by framework after form created.
        /// </summary>
        public override void OnInitializeComponent()
        {
            this.Edt_Dde = ((SAPbouiCOM.EditText)(this.GetItem("Edt_Dde").Specific));
            this.Edt_Dat = ((SAPbouiCOM.EditText)(this.GetItem("Edt_Dat").Specific));
            this.Btn_Pesquisar = ((SAPbouiCOM.Button)(this.GetItem("Btn_Pes").Specific));
            this.Btn_Pesquisar.ClickAfter += this.Btn_Pesquisar_ClickAfter;
            this.ComboFilial = ((SAPbouiCOM.ComboBox)(this.GetItem("Item_14").Specific));
            this.Grid_Doc = ((SAPbouiCOM.Grid)(this.GetItem("Grid_1").Specific));
            this.Grid_Doc.ClickAfter += this.Grid_Doc_ClickAfter;
            this.Grid_Itm = ((SAPbouiCOM.Grid)(this.GetItem("GRD_ITM").Specific));
            this.Button0 = ((SAPbouiCOM.Button)(this.GetItem("Item_12").Specific));
            this.Button0.PressedAfter += new SAPbouiCOM._IButtonEvents_PressedAfterEventHandler(this.Btn_Processar);
            this.OnCustomInitialize();

        }

        private void Grid_Doc_ClickAfter(object sboObject, SAPbouiCOM.SBOItemEventArg pVal)
        {
            this.UIAPIRawForm.Freeze(true);


            if (this.Grid_Doc.Rows.Count == 0) return;

            string DocEntry = this.DT_Doc.GetValue("DocEntry", pVal.Row).ToString();
            string tipo = this.DT_Doc.GetValue("Tipo", pVal.Row).ToString();

            
            try
            {
                ADService pdvMatrix = new ADService((Company)Application.SBO_Application.Company.GetDICompany());

                List<ADModeltem> lista = pdvMatrix.BuscarListaDadosItem(DocEntry, tipo);

                CarregarItensGrid(lista);
            }
            catch (Exception ex)
            {
                Application.SBO_Application.SetStatusBarMessage($"{ex.Message}");
                
            }
            finally
            {
                this.UIAPIRawForm.Freeze(false);
            }
        }

        /// <summary>
        /// Initialize form event. Called by framework before form creation.
        /// </summary>
        public override void OnInitializeFormEvents()
        {

        }


        private void OnCustomInitialize()
        {
            DT_Doc = this.UIAPIRawForm.DataSources.DataTables.Item("DT_Doc");
            DT_Itm = this.UIAPIRawForm.DataSources.DataTables.Item("DT_Itm");

            this.Grid_Doc.SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single;
        }
        

        private void Btn_Pesquisar_ClickAfter(object sboObject, SAPbouiCOM.SBOItemEventArg pVal)
        {
            try
            {
                this.UIAPIRawForm.Freeze(true);

                if (String.IsNullOrEmpty(Edt_Dde.Value.ToString())) throw new Exception("Informar data de início.");
                if (String.IsNullOrEmpty(Edt_Dat.Value.ToString())) throw new Exception("Informar data de fim.");
                PesquisarInformaoes();

            }
            catch (Exception ex)
            {
                Application.SBO_Application.SetStatusBarMessage($"{ex.Message}");
                
            }
            finally
            {
                this.UIAPIRawForm.Freeze(false);
            }
        }
        
        private void PesquisarInformaoes()
        {

            DateTime DataDe = DateTime.ParseExact(Edt_Dde.Value, "yyyyMMdd", CultureInfo.InvariantCulture);
            DateTime DataAte = DateTime.ParseExact(Edt_Dat.Value, "yyyyMMdd", CultureInfo.InvariantCulture);

            ADService pdvMatrix = new ADService((Company)Application.SBO_Application.Company.GetDICompany());

            List<ADModel> lista = pdvMatrix.BuscarListaDados(DataDe, DataAte);

            DT_Doc.Rows.Clear();
            for (int i = 0; i < lista.Count; i++)
            {
                DT_Doc.Rows.Add();
                DT_Doc.SetValue("Tipo", i, lista[i].Tipo);
                DT_Doc.SetValue("Documento", i, lista[i].Numero);
                DT_Doc.SetValue("Data", i, lista[i].Data);
                DT_Doc.SetValue("Parceiro", i, lista[i].Parceiro);
                DT_Doc.SetValue("Nome", i, lista[i].Nome);
                DT_Doc.SetValue("Valor", i, lista[i].ValorTotal);
                DT_Doc.SetValue("Filial", i, lista[i].Filial);
                DT_Doc.SetValue("DocEntry", i, lista[i].NumeroPrimario);
            }
            if (lista.Count.Equals(0)) Application.SBO_Application.StatusBar.SetSystemMessage("Nenhum dado encontrado.", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
        }
        


        private void CarregarItensGrid(List<ADModeltem> lista)
        {
            
            DT_Itm.Rows.Clear();
            for (int i = 0; i < lista.Count; i++)
            {
                DT_Itm.Rows.Add();
                DT_Itm.SetValue("Item", i, lista[i].Item);
                DT_Itm.SetValue("Descrição", i, lista[i].Descricao);
                DT_Itm.SetValue("Quantidade", i, lista[i].Quantidade);
                DT_Itm.SetValue("Unid Medida", i, lista[i].UnidMedida);
                DT_Itm.SetValue("Quant conferida", i, lista[i].QuantidadeConferida);
                DT_Itm.SetValue("Divergência", i, lista[i].Divergencia);

            }
            if (lista.Count.Equals(0)) throw new Exception("Nenhum dado encontrado.");
        }

        private SAPbouiCOM.Button Button0;

        private void Btn_Processar(object sboObject, SAPbouiCOM.SBOItemEventArg pVal)
        {
            try
            {
                this.UIAPIRawForm.Freeze(true);

                if (this.ComboFilial.Selected == null || (this.ComboFilial.Selected.Value != "A" && this.ComboFilial.Selected.Value != "D"))
                    throw new Exception("Selecione uma ação.");

                string acao = this.ComboFilial.Selected.Value;

                List<ADModel> listaModels = CarregarGridDocLista();
                
                listaModels = listaModels.Where(x => x.Selecionado.Contains("Y")).ToList();

                var pBar = Application.SBO_Application.StatusBar.CreateProgressBar("Atualizando documentos..", listaModels.Count, true);

                var ListaNFS = listaModels.Where(x => x.Tipo == "NFS").ToList();
                var ListaRec = listaModels.Where(x => x.Tipo == "Recebimento").ToList();

                Company oCmp = (Company)Application.SBO_Application.Company.GetDICompany();

                NotaSaidaService notaservice = new NotaSaidaService(oCmp);
                RecMercadoriaService recmercadoriaservice = new RecMercadoriaService(oCmp);
                
                try
                {
                    foreach (ADModel elemento in ListaNFS)
                    {
                        notaservice.AtualizarPrc(acao, elemento.NumeroPrimario);
                        pBar.Value += 1;
                    }

                    foreach (ADModel elemento in ListaRec)
                    {
                        recmercadoriaservice.AtualizarPrcRecebimento(acao, elemento.NumeroPrimario);
                        pBar.Value += 1;
                    }

                    this.PesquisarInformaoes();
                    this.DT_Itm.Rows.Clear();
                    this.Grid_Itm.Item.Refresh();

                }
                catch (Exception ex)
                {
                    Application.SBO_Application.SetStatusBarMessage(ex.Message);
                }
                finally
                {
                    pBar.Stop();
                }


            }
            catch(Exception ex)
            {
                Application.SBO_Application.SetStatusBarMessage(ex.Message);
            }
            finally
            {
                this.UIAPIRawForm.Freeze(false);
            }

        }

        private List<ADModel> CarregarGridDocLista()
        {
            List<ADModel> listaModels = new List<ADModel>();

            for (int i = 0; i < this.Grid_Doc.Rows.Count; i++)
            {
                listaModels.Add(new ADModel()
                {
                    Selecionado = DT_Doc.GetValue("Selecionar", i).ToString(),
                    NumeroPrimario = (int)DT_Doc.GetValue("DocEntry", i),
                    Tipo = DT_Doc.GetValue("Tipo", i).ToString(),
                    Numero = (int)DT_Doc.GetValue("Documento", i),
                    Data = (DateTime)DT_Doc.GetValue("Data", i),
                    Parceiro = DT_Doc.GetValue("Parceiro", i).ToString(),
                    Nome = DT_Doc.GetValue("Nome", i).ToString(),
                    ValorTotal = (double)DT_Doc.GetValue("Valor", i),
                    Filial = DT_Doc.GetValue("Filial", i).ToString()
                });
            }
            return listaModels;
        }
    }
}