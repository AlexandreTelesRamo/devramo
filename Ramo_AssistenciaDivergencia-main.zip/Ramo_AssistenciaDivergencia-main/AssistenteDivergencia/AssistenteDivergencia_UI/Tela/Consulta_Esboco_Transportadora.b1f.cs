﻿using System;
using System.Collections.Generic;
using AssistenteDivergencia_UI.Models;
using AssistenteDivergencia_UI.Service;
using SAPbouiCOM;
using SAPbouiCOM.Framework;


namespace AssistenteDivergencia_UI.Tela
{
    [FormAttribute("AssistenteDivergencia_UI.Tela.Consulta_Esboco_Transportadora", "Tela/Consulta_Esboco_Transportadora.b1f")]
    class Consulta_Esboco_Transportadora : UserFormBase
    {

        private SAPbouiCOM.Button Btn_Pesquisar;
        private SAPbouiCOM.Button Btn_Atualizar;
        private SAPbouiCOM.DataTable DT_Grid;
        private SAPbouiCOM.Grid Grid;
        ChooseFromList oCFLTransportadora;

        public Consulta_Esboco_Transportadora()
        {

        }

        /// <summary>
        /// Initialize components. Called by framework after form created.
        /// </summary>
        public override void OnInitializeComponent()
        {
            this.Btn_Atualizar = ((SAPbouiCOM.Button)(this.GetItem("Btn_Att").Specific));
            this.Btn_Atualizar.PressedAfter += new SAPbouiCOM._IButtonEvents_PressedAfterEventHandler(this.Btn_Atualizar_PressedAfter);
            this.Btn_Pesquisar = ((SAPbouiCOM.Button)(this.GetItem("Btn_Pes").Specific));
            this.Btn_Pesquisar.PressedAfter += new SAPbouiCOM._IButtonEvents_PressedAfterEventHandler(this.Btn_Pesquisar_PressedAfter);
            this.Grid = ((SAPbouiCOM.Grid)(this.GetItem("Grid").Specific));
            this.OnCustomInitialize();

        }




        /// <summary>
        /// Initialize form event. Called by framework before form creation.
        /// </summary>
        public override void OnInitializeFormEvents()
        {
        }


        private void OnCustomInitialize()
        {
            DT_Grid = this.UIAPIRawForm.DataSources.DataTables.Item("DT_Grid");
            oCFLTransportadora = this.UIAPIRawForm.ChooseFromLists.Item("CFL_OCRD");
            ChooseFromList();


            this.Grid.ChooseFromListAfter += Grid_ChooseFromListAfter;
        }
        private void PesquisarInformaoes()
        {

            CETService pdvMatrix = new CETService((SAPbobsCOM.Company)SAPbouiCOM.Framework.Application.SBO_Application.Company.GetDICompany());

            List<CETModel> lista = pdvMatrix.BuscarListaDados();

            DT_Grid.Rows.Clear();
            for (int i = 0; i < lista.Count; i++)
            {
                DT_Grid.Rows.Add();
                DT_Grid.SetValue("N°Interno", i, lista[i].NumeroInternoSAP);
                DT_Grid.SetValue("N°Documento", i, lista[i].NumeroDocumento);
                DT_Grid.SetValue("Cliente", i, lista[i].Cliente);
                DT_Grid.SetValue("Nome do Cliente", i, lista[i].NomeCliente);
                DT_Grid.SetValue("Data de Lançamento", i, lista[i].DataLancamento);
                DT_Grid.SetValue("Data de Entrega", i, lista[i].DataEntrega);
                DT_Grid.SetValue("Total", i, lista[i].Total);
            }
            if (lista.Count.Equals(0)) SAPbouiCOM.Framework.Application.SBO_Application.StatusBar.SetSystemMessage("Nenhum dado encontrado.", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
        }

        private void ChooseFromList()
        {


            Conditions oConds = oCFLTransportadora.GetConditions();
            Condition oCond = oConds.Add();

            oCond.Alias = "CardType";
            oCond.Operation = BoConditionOperation.co_EQUAL;
            oCond.CondVal = "S";

            oCFLTransportadora.SetConditions(oConds);
        }

        private void Grid_ChooseFromListAfter(object sboObject, SAPbouiCOM.SBOItemEventArg pVal)
        {
            try
            {
                this.UIAPIRawForm.Freeze(true);
                SAPbouiCOM.ISBOChooseFromListEventArg oCflEvent = (SAPbouiCOM.ISBOChooseFromListEventArg)pVal;
                if (oCflEvent.SelectedObjects != null)
                {
                    DT_Grid.SetValue(oCflEvent.ColUID, pVal.Row, oCflEvent.SelectedObjects.GetValue(0, 0).ToString());
                    this.UIAPIRawForm.Refresh();
                }
            }
            catch (Exception)
            {

            }
            finally
            {
                this.UIAPIRawForm.Freeze(false);
            }
        }

        private void Btn_Pesquisar_PressedAfter(object sboObject, SBOItemEventArg pVal)
        {
            try
            {
                this.UIAPIRawForm.Freeze(true);
                PesquisarInformaoes();

            }
            catch (Exception ex)
            {
                SAPbouiCOM.Framework.Application.SBO_Application.SetStatusBarMessage($"{ex.Message}");

            }
            finally
            {
                this.UIAPIRawForm.Freeze(false);
            }
        }

        private void Btn_Atualizar_PressedAfter(object sboObject, SBOItemEventArg pVal)
        {
            try
            {
                this.UIAPIRawForm.Freeze(true);
                // Busca todos os modelos com  a transportadora preenchida
                List<CETModel> lista = new List<CETModel>();

                for (int i = 0; i < DT_Grid.Rows.Count; i++)
                {
                    if (!String.IsNullOrEmpty(DT_Grid.Columns.Item("Transportadora").Cells.Item(i).Value.ToString()))
                    {
                        lista.Add(new CETModel()
                        {
                            NumeroInternoSAP = (int)DT_Grid.GetValue("N°Interno", i),
                            NumeroDocumento = (int)DT_Grid.GetValue("N°Documento", i),
                            Cliente = (string)DT_Grid.GetValue("Cliente", i),
                            NomeCliente = (string)DT_Grid.GetValue("Nome do Cliente", i),
                            DataLancamento = (DateTime)DT_Grid.GetValue("Data de Lançamento", i),
                            DataEntrega = (DateTime)DT_Grid.GetValue("Data de Entrega", i),
                            Total = (double)DT_Grid.GetValue("Total", i),
                            Transportadora = (string)DT_Grid.GetValue("Transportadora", i)
                        });
                    }
                }

                if (lista.Count == 0)
                    throw new Exception("Preencher pelo menos uma transportadora.");

                // Percorre a lista com transportadora preenchida e atualiza no SAP
                foreach (CETModel model in lista)
                    using (EsbocoEntregaService entrega = new EsbocoEntregaService((SAPbobsCOM.Company)SAPbouiCOM.Framework.Application.SBO_Application.Company.GetDICompany()))
                        entrega.AtualizarTransportadora(model, model.Transportadora);

                PesquisarInformaoes();

            }
            catch (Exception ex)
            {
                SAPbouiCOM.Framework.Application.SBO_Application.SetStatusBarMessage($"{ex.Message}");
            }
            finally
            {
                this.UIAPIRawForm.Freeze(false);
            }
        }
    }
}
