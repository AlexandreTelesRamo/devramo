﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Models
{
    public class ADModel
    {
        public string Selecionado { get; set; }

        public int NumeroPrimario { get; set; }

        public int Numero { get; set; }

        public string Tipo { get; set; }

        public DateTime Data { get; set; }

        public string Parceiro { get; set; } 

        public string Nome { get; set; }

        public double ValorTotal { get; set; }

        public string Filial { get; set; }
    }
}
