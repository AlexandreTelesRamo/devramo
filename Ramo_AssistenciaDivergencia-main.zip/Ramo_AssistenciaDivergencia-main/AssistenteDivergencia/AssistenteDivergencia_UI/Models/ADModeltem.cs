﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Models
{
    public class ADModeltem
    {
        public int NumeroPrimario { get; set; }

        public string Item { get; set; }

        public string Descricao { get; set; }

        public string Quantidade { get; set; }

        public string UnidMedida { get; set; }

        public string QuantidadeConferida { get; set; }

        public string Divergencia { get; set; }
    }
}
