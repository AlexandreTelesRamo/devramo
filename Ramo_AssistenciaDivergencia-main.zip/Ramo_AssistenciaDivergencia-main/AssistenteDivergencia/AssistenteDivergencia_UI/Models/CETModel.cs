﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Models
{
    public class CETModel
    {
        public int NumeroInternoSAP { get; set; }
        public int NumeroDocumento { get; set; }
        public string Cliente { get; set; }
        public string NomeCliente { get; set; }
        public DateTime DataLancamento { get; set; }
        public DateTime DataEntrega { get; set; }
        public double Total { get; set;}
        public string Transportadora { get; set; }
    }
}
