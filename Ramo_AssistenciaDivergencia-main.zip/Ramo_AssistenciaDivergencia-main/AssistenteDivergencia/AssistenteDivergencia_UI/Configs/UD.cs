﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssistenteDivergencia_UI.Configs
{
    public class UD
    {
        public const string MENU_PASTA_ASSISTENCIA_DIVERGENCIA = "ADiv";
        public const string MENU_FORM_ASSISTENTE_INTEGRACAO = "Aint";
        public const string MENU_PASTA_CONSULTA_TRANSPORTADORA = "ACT";
        public const string MENU_FORM_CONSULTA_ESBOCO_TRANSPORTADORA = "Acet";

    }
}
