﻿using System;
using System.Collections.Generic;
using System.Xml;
using SAPbouiCOM.Framework;

namespace Consulta_Esboco_Transportadora
{
    [FormAttribute("Consulta_Esboco_Transportadora.Form1", "Form1.b1f")]
    class Form1 : UserFormBase
    {
        public Form1()
        {
        }

        /// <summary>
        /// Initialize components. Called by framework after form created.
        /// </summary>
        public override void OnInitializeComponent()
        {
        }

        /// <summary>
        /// Initialize form event. Called by framework before form creation.
        /// </summary>
        public override void OnInitializeFormEvents()
        {
        }
    }
}